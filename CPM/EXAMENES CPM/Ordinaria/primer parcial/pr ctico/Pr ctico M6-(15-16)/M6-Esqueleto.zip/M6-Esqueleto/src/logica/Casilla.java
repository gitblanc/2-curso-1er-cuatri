package logica;

public class Casilla {
	private int valor;
	
	public Casilla() {
//		setValor ();
	}
	public int getValor() {
		return valor;
	}
	public void setValor(int valor) {
		this.valor = valor;
	}
}
