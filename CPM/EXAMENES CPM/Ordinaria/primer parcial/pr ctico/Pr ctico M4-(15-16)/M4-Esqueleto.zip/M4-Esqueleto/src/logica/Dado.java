package logica;

public class Dado {
	
//	public static int lanzar ()
	{
//		int resultado =  (int) (Math.random() * VALORDADO) + 1;
//		return resultado;
	}
}
